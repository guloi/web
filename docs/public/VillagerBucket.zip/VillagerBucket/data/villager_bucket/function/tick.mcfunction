# 获取村民数据
execute as @e[type=item] at @s if entity @e[type=villager,distance=..1] run function villager_bucket:villager_xp_check

# 放出村民
execute as @e[type=item,limit=1,name="铁桶"] at @s store result storage villager_bucket_get_id:id id int 1 run data get entity @s Item.components.minecraft:lore[10]
execute as @e[type=item,limit=1,name="铁桶"] at @s run data modify storage villager_bucket_get_id:id id set from entity @s Item.components.minecraft:lore[10]
execute as @e[type=item,limit=1,name="铁桶"] at @s run function villager_bucket:put_villager_get_id with storage villager_bucket_get_id:id