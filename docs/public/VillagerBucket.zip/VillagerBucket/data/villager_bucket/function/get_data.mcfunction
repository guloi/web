# 获取村民附近掉落物的id
execute store result storage villager_bucket:bucket_test Item.id int 1 run data get entity @s Item.id




# 将其存入计分板 #itemId
execute store result score #itemId item run data get storage villager_bucket:bucket_test Item.id
# 比对id 16 -> bucket # 此处有误 会改的
# 此次存储无关紧要#############
execute if score #itemId item matches 16 store result storage villager_bucket:data VillagerData int 1 run scoreboard players get #itemId item


# 存储VillagerData
data modify storage villager_bucket:data VillagerData set from entity @e[type=villager,distance=..1,limit=1] VillagerData




# 存储Offers
execute if score #itemId item matches 16 store result storage villager_bucket:data Offers int 1 run scoreboard players get #itemId item
data modify storage villager_bucket:data Offers set from entity @e[type=villager,distance=..1,limit=1] Offers

# 存储Xp
execute if score #itemId item matches 16 store result storage villager_bucket:data Xp int 1 run scoreboard players get #itemId item
data modify storage villager_bucket:data Xp set from entity @e[type=villager,distance=..1,limit=1] Xp

# 计入此时桶的编号
scoreboard players add #BucketId item 1

# 临时将信息打包存入存储
execute store result storage villager_bucket:bucket_info id int 1 run scoreboard players get #BucketId item
execute store result storage villager_bucket:bucket_info villager_data int 1 run scoreboard players get #BucketId item
data modify storage villager_bucket:bucket_info villager_data set from storage villager_bucket:data VillagerData
data modify storage villager_bucket:bucket_info target set from storage villager_bucket:bucket_info id
data modify storage villager_bucket:bucket_info nbt_path set from storage villager_bucket:bucket_info id
data modify storage villager_bucket:bucket_info profession set from storage villager_bucket:bucket_info villager_data.profession
data modify storage villager_bucket:bucket_info level set from storage villager_bucket:bucket_info villager_data.level
data modify storage villager_bucket:bucket_info type set from storage villager_bucket:bucket_info villager_data.type
data modify storage villager_bucket:bucket_info Xp set from storage villager_bucket:data Xp

# 存储数据
function villager_bucket:store with storage villager_bucket:bucket_info

# 击杀桶和村民并生成新的桶
function villager_bucket:summon_bucket with storage villager_bucket:bucket_info
kill @s
kill @e[type=villager,distance=..1]