scoreboard players set #Rresult item 0
$execute if data storage $(remove) $(remove) run scoreboard players set #Rresult item 1
$data remove storage $(remove) $(remove)
execute store result storage villager_bucket:id result int 1 run scoreboard players get #Rresult item
data modify storage villager_bucket_remove result set from storage villager_bucket:id result