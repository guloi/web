scoreboard players set #remove item 1
scoreboard players set #remove_end item 1
tellraw @p [{text:"这将清除所有已存储的村民    ",color:red},{text:"执行操作",color: "yellow",underlined:true,click_event:{action:"run_command",command:"function villager_bucket:removedata"}}]