execute store result score #lastVillagerXp item run data get entity @e[type=villager,distance=..1,limit=1] Xp
execute if score #lastVillagerXp item matches 0 run tellraw @p {"text":"需要至少进行过一次交易的村民",color:red}
execute unless score #lastVillagerXp item matches 0 run function villager_bucket:get_data