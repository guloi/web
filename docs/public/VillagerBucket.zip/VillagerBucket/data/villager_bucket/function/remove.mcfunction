$function villager_bucket:remove_storage {remove:$(remove)}
scoreboard players set #remove_end item 1
$scoreboard players set #storeid item $(remove)
scoreboard players operation #storeid item -= #remove_end item
$tellraw @p [{text:"正在清理第$(remove)/$(all)个存储 | $(result) <- 对应存储 :"}, {score:{name:"#storeid",objective:"item"}}]
execute if score #remove item <= #BucketId item run function villager_bucket:removedata
execute if score #remove item > #BucketId item run scoreboard players set #BucketId item 0
execute if score #remove item > #BucketId item run scoreboard players set #Rresult item 0