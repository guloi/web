$data remove storage $(remove) $(remove)
scoreboard players set #remove_end item 1
$tellraw @p {text:"正在清理第$(remove)/$(all)个存储"}
execute if score #remove item <= #BucketId item run function villager_bucket:removedata
execute if score #remove item > #BucketId item run scoreboard players set #BucketId item 0