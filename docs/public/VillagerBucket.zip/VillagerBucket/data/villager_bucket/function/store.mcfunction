$execute store result storage $(target) $(nbt_path) int 1 run scoreboard players get #itemId item
$data modify storage $(target) $(nbt_path) set from storage villager_bucket:data