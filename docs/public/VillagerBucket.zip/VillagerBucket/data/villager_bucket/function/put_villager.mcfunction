$summon villager ~ ~ ~ {VillagerData:$(VillagerData),Offers:$(Offers),Xp:$(Xp)}
#execute as @e[type=villager] at @s run data modify entity @s VillagerData.level set value 2
kill @s
