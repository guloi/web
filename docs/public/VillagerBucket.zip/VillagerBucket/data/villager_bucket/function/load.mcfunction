tellraw @p {text:"Datapack Loaded",color:green}

# init
scoreboard objectives add item dummy
scoreboard players set #itemId item 0