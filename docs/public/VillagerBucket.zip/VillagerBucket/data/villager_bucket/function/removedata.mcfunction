execute store result storage villager_bucket_remove remove int 1 run scoreboard players get #remove item
execute store result storage villager_bucket:id id int 1 run scoreboard players get #BucketId item
data modify storage villager_bucket_remove all set from storage villager_bucket:id id
execute if score #remove_end item matches 1 run scoreboard players add #remove item 1
execute if score #remove_end item matches 1 run function villager_bucket:remove with storage villager_bucket_remove
execute if score #remove_end item matches 1 run scoreboard players set #remove_end item 0