execute as @e[tag=point,limit=1] at @s run tp @s @p
execute as @e[tag=point,limit=1] at @s run tp @s ^ ^ ^4
execute as @e[tag=point,limit=1] at @s if entity @e[type=!minecraft:player,distance=..2] run tp @s @e[distance=..2,limit=1,type=!player,tag=!text]
execute as @e[tag=text] at @s run tp @s @e[tag=point,limit=1]
execute as @e[tag=text] at @s run tp @s ^ ^2 ^ facing entity @p eyes
execute as @e[tag=point] at @s if score @p mode matches 0 run function tellme:hud
execute as @e[tag=point] at @s if score @p mode matches 1 run function tellme:hud_all