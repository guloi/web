# 把point和text移到目标位置
execute as @e[tag=point,limit=1] at @s if score #follow settings matches 0 run tp @s @p
execute as @e[tag=point,limit=1] at @s if score #follow settings matches 1 run tp @s @e[tag=follow,limit=1]
execute as @e[tag=point,limit=1] at @s if score #follow settings matches 0 run tp @s ^ ^ ^6
execute as @e[tag=point,limit=1] at @s if entity @e[type=!minecraft:player,distance=..2] run tp @s @e[distance=..2,limit=1,type=!player,tag=!text]
# 当未选中时将info:all设为空气
execute as @e[tag=point,limit=1] at @s if entity @e[type=!minecraft:player,distance=..8] if score #stop settings matches 0 run data modify storage info:all info set value ""


execute as @e[tag=text] at @s run tp @s @e[tag=point,limit=1]
execute as @e[tag=text] at @s run tp @s ^ ^2 ^ facing entity @p eyes
execute as @e[tag=point] at @s if score @p settings matches 0 run function tellme:hud
execute as @e[tag=point] at @s if score @p settings matches 1 run function tellme:hud_all
