# 为选中实体添加follow标签
$scoreboard players set #follow settings $(follow)
execute if score #follow settings matches 1 as @e[tag=point] at @s run tag @e[type=!minecraft:player,distance=..2,tag=!point,tag=!text] add follow
execute if score #follow settings matches 0 run tag @e[tag=follow] remove follow

