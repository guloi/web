kill @e[tag=point]
kill @e[type=text_display,tag=text]
execute as @p at @s run summon armor_stand ^ ^ ^ {"Tags":["point"],"Invisible":1b}
execute as @p at @s run tag @e[distance=..2,type=armor_stand,limit=1] add point
execute as @p at @s run summon text_display ~ ~ ~
execute as @p at @s run tag @e[type=text_display,distance=..2] add text
# 创建一个计分板以记录设置
scoreboard objectives add settings dummy
# 当stop为1时暂停
scoreboard players set #stop settings 0
# follow决定hud是否跟随实体
scoreboard players set #follow settings 0
# 初始化存储 存储的信息不重要
execute store result storage info:all info int 1 run data get storage info:all info
