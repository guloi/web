kill @e[tag=point]
kill @e[type=text_display,tag=text]
execute as @p at @s run summon armor_stand ^ ^ ^ {"Tags":["point"],"Invisible":1b}
execute as @p at @s run tag @e[distance=..2,type=armor_stand,limit=1] add point
execute as @p at @s run summon text_display ~ ~ ~
execute as @p at @s run tag @e[type=text_display,distance=..2] add text
# 创建一个计分板以选择模式
scoreboard objectives add mode dummy
scoreboard players set @p mode 0