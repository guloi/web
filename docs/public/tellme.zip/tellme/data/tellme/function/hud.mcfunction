# 用法（存储） function tellme:storage {target:"", nbt_path:"", nbt_path2:""}
# 用法（修改） function tellme:modify_storage {modify_target:"", modify_nbt_path:"", from:"", modify_nbt_path2:""}
# 获取x坐标
function tellme:storage {target:"info:pos", nbt_path:"_Posx", nbt_path2:"Pos[0]"}
# 获取y坐标
function tellme:storage {target:"info:pos", nbt_path:"_Posy", nbt_path2:"Pos[1]"}
# 获取z坐标
function tellme:storage {target:"info:pos", nbt_path:"_Posz", nbt_path2:"Pos[2]"}
# 获取tags信息
function tellme:storage {target:"info:tag", nbt_path:"tag", nbt_path2:"Tags"}
function tellme:modify_storage {modify_target:"info:tag", modify_nbt_path:"tag",from:"entity @e[type=!minecraft:player,limit=1,distance=..2,tag=!point,tag=!text]", modify_nbt_path2:"Tags"}
# 获取手持物品
function tellme:storage {target:"info:mainhand", nbt_path:"mainhand_id", nbt_path2:"equipment.mainhand.id"}
function tellme:modify_storage {modify_target:"info:mainhand", modify_nbt_path:"mainhand_id",from:"entity @e[type=!minecraft:player,limit=1,distance=..2,tag=!point,tag=!text]", modify_nbt_path2:"equipment.mainhand.id"}
#获取血量
function tellme:storage {target:"info:health", nbt_path:"health", nbt_path2:"Health"}
#获取物品id（掉落物）
function tellme:storage {target:"info:item", nbt_path:"id", nbt_path2:"Item.id"}
function tellme:modify_storage {modify_target:"info:item", modify_nbt_path:"id",from:"entity @e[type=!minecraft:player,limit=1,distance=..2,tag=!point,tag=!text]", modify_nbt_path2:"Item.id"}
#将信息整合并显示出来
data merge storage info:all {"why":{"text":[{"text":"Posx: ", "color":"gold"}, {"nbt":"_Posx", "storage":"info:pos" , "color":"red"}, {"text":"   Posy: ", "color":"gold"}, {"nbt":"_Posy", "storage":"info:pos" , "color":"red"}, {"text":"   Posz: ", "color":"gold"}, {"nbt":"_Posz", "storage":"info:pos" , "color":"red"}, {"text":"   \nTags: ", "color":"gold"}, {"nbt":"tag", "storage":"info:tag" , "color":"red"}, {"text":"   Mainhand: ", "color":"gold"}, {"nbt":"mainhand_id", "storage":"info:mainhand" , "color":"red"}, {"text":"   Health: ", "color":"gold"}, {"nbt":"health", "storage":"info:health" , "color":"red"}, {"text":"   \nItem: ", "color":"gold"}, {"nbt":"id", "storage":"info:item" , "color":"red"}]}}
data modify entity @e[tag=text,limit=1] text set from storage info:all why.text