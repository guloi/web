kill @e[tag=point]
kill @e[tag=text]