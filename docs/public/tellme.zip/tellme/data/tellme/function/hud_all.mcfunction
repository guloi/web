execute store result storage info:all info int 1 run data get entity @e[type=!minecraft:player,limit=1,distance=..2,tag=!point,tag=!text]
data modify storage info:all info set from entity @e[type=!minecraft:player,limit=1,distance=..2,tag=!point,tag=!text]
data merge storage info:all {display:{"text":[{"nbt":"info", "storage":"info:all"}]}}
data modify entity @e[tag=text,limit=1] text set from storage info:all display.text