# 获取信息
execute if score #stop settings matches 0 if score #follow settings matches 0 run data modify storage info:all info set from entity @e[type=!minecraft:player,limit=1,distance=..2,tag=!point,tag=!text]
execute if score #stop settings matches 0 if score #follow settings matches 1 run data modify storage info:all info set from entity @e[tag=follow,limit=1]
# 显示出来
data merge storage info:all {display:{"text":[{"nbt":"info", "storage":"info:all"}]}}
data modify entity @e[tag=text,limit=1] text set from storage info:all display.text