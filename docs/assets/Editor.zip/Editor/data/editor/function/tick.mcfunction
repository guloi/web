# 提起
execute as @e[type=snowball] at @s unless block ~ ~-1 ~ #air if score #suc temp matches 1.. run function editor:pickup
execute as @e[type=block_display,tag=block] at @s run tp @s @p
execute as @e[type=block_display,tag=block] at @s run tp @s ^-0.6 ^0.4 ^4 facing entity @p feet




# 获取玩家面朝的方向
execute if entity @p[y_rotation=-10..10] run data modify storage editor:blocklist facing set value "facing=south"
execute if entity @p[y_rotation=150..210] run data modify storage editor:blocklist facing set value "facing=north"
execute if entity @p[y_rotation=-110..-70] run data modify storage editor:blocklist facing set value "facing=east"
execute if entity @p[y_rotation=70..110] run data modify storage editor:blocklist facing set value "facing=west"



# 放下
data modify storage editor:blocklist id set from storage editor:blocklist blist.id
data modify storage editor:blocklist Items set from storage editor:blocklist blist.Items
execute if score @p right_check matches ..1 if score #isCommon temp matches 0.. run function editor:putblock with storage editor:blocklist
execute if score @p right_check matches ..1 if score #isCommon temp matches 1.. run function editor:putblock_d with storage editor:blocklist
execute if score @p right_check matches 1.. if score #suc temp matches 0 run tellraw @p {text:"无方向方块或出错了 此方块将被直接放置",color:red}
execute if score @p right_check matches 1.. if score #suc temp matches 0 run function editor:putblock_n with storage editor:blocklist




# 右键检测-重置
function editor:right-check

