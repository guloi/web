$execute as @e[type=block_display,limit=1,tag=block] at @s if score @p right_check matches 1.. run setblock ^ ^ ^ $(id)[$(facing)]
execute if score @p right_check matches 1.. run kill @e[type=block_display,tag=block]
execute if score @p right_check matches 1.. run scoreboard players set #isCommon temp 1
scoreboard players set #suc temp 1