execute if score @p right_check matches 1.. run scoreboard players set @p right_check 0
