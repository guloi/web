# 针对方块实体
# 处理Items
execute as @e[type=snowball] at @s if data block ~ ~-1 ~ Items run scoreboard players set #isCommon temp 0
execute as @e[type=snowball] at @s if data block ~ ~-1 ~ Items run data modify storage editor:blocklist blist set from block ~ ~-1 ~


# 破坏方块
setblock ~ ~-1 ~ air destroy
# 确定此时方块未放下
scoreboard players set #suc temp 0

#tellraw @p {text:"已选择",color:green}
# 获取方块信息（非方块实体）
execute if score #isCommon temp matches 1.. store result storage editor:blocklist blist int 1 as @e[type=snowball] at @s run data get storage editor:blocklist
execute if score #isCommon temp matches 1.. as @e[type=snowball] at @s run data modify storage editor:blocklist blist set from entity @e[type=item,distance=..2,limit=1] Item
# 击杀掉落物
kill @e[type=item,distance=..2]
# 创建方块展示实体
function editor:blockcreate with storage editor:blocklist blist
# 击杀雪球
kill @s

