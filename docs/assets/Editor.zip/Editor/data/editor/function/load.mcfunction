# 提示
tellraw @p {text:"Datapack Loaded", color:green}
tellraw @p {text:"目前做了极小部分数据保留 额、可能会出现些问题", color:green}
tellraw @p {text:"使用/function editor:help获取帮助", color:green}

# 给予工具 
execute as @p at @s if entity @s[tag=!gotTools] run give @s carrot_on_a_stick[item_name="Action",lore=["执行操作"],enchantment_glint_override=true]
execute as @p at @s if entity @s[tag=!gotTools] run give @s snowball[item_name="Selector",lore=["选中器"],enchantment_glint_override=true]
execute as @p at @s if entity @s[tag=!gotTools] run tag @s add gotTools

# init
# 创建右键计分板&普通计分板
scoreboard objectives add right_check minecraft.used:carrot_on_a_stick
scoreboard objectives add temp dummy
# 方块数据存储
execute as @p at @s if entity @s[tag=!gotTools] store result storage editor:blocklist blist int 1 run data get storage editor:blocklist