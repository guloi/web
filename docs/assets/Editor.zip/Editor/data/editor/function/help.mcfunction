tellraw @p [{text:"方块无法放下？方块无法被提起？",color:red},{text:"  点我尝试解决",color:green,underlined:true,click_event:{"action":"run_command","command":"scoreboard players set #isCommon temp 1"}}]
