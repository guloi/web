$execute as @e[type=snowball] at @s run summon block_display ~ ~ ~ {block_state:{Name:"$(id)"}}
execute as @e[type=block_display,distance=..3] at @s run tag @s add block